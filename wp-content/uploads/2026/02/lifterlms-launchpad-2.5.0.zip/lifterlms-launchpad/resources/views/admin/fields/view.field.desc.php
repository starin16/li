<th colspan="2" style="font-weight: normal;">
    <?php echo wpautop(wptexturize(wp_kses_post($desc))); ?>
</th>
