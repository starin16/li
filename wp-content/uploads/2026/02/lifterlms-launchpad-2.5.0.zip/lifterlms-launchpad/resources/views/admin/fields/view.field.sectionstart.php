<?php do_action('launchpad_settings_' . sanitize_title($id) . '_before'); ?>

<div class="launchpad-widget-full <?php echo $class; ?>">
    <div class="launchpad-widget">

<?php do_action('launchpad_settings_' . sanitize_title($id) . '_start'); ?>