<?php do_action('launchpad_settings_' . sanitize_title($id) . '_end'); ?>

        </table>
    </div>
</div>

<?php do_action('launchpad_settings_' . sanitize_title($id) . '_after'); ?>
