<?php

/**
 * Add defaults for new new options added in 1.3.0
 */
add_option( 'launchpad_settings_font_color_body', '#444444' );

return true;