<?php
/**
 * Add defaults for new new options added in 2.0.2
 */
add_option( 'launchpad_settings_custom_js_wrapper', 'yes' );

return true;