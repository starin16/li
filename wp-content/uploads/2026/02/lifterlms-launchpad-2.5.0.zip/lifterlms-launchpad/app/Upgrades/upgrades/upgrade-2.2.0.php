<?php
/**
 * Add defaults for new new options added in 2.2.0
 */
add_option( 'launchpad_settings_container_margin_top', '40' );
add_option( 'launchpad_settings_container_margin_bottom', '105' );

return true;