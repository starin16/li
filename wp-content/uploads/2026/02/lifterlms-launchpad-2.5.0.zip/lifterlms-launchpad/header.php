<?php
echo (new LaunchPad\ThemeLayout\HeaderLayout)->output();
