<?php
/**
 * LaunchPad Theme
 *
 * WARNING: This file does nothing. Overriding this template will not affect the sidebar template.
 * The sidebar theme styles are controlled from the View located in inc/Views/Theme/view.sidebar.php
 */